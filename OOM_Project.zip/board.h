#ifndef __board
#define __board

#include <string>
#include "lecture.h"

using std::string;
namespace OCMS
{	
    // Class for board-level paid courses
	class board
	{
	protected:
		string standard;
		string price;
		int duration_in_min;
		int no_of_tests;
		int course_code;

	public:
		board(string, string, int, int);
		virtual void show_details();
		void purchase_course(string s);
		int get_code();
		static int i;
	};
}
#endif