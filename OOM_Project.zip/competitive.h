#ifndef __competitive
#define __competitive

#include <string>
#include "lecture.h"
#include "board.h"

using std::string;
using OCMS::board;

namespace OCMS
{	
    // A derived class of board for competitive-level courses
	class competitive : public board

	{
	private:
		string exam_type;
		int no_of_dpps;
		string formula_book[3];

	public:
		competitive(string, string, int, int, string, int, string formula_book[]);
		string get_standard();
		string get_exam_type();
		void show_details();
	};
}
#endif