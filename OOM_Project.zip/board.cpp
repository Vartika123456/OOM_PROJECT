#include <bits/stdc++.h>
#include "board.h"
#include "student_profile.h" // Header file including all class declarations

using OCMS::board;
using OCMS::student_profile;
using namespace std;

extern student_profile s1;

// contructor function for board-level courses
board::board(string standard, string price, int duration_in_min, int no_of_tests)
{
    this->standard = standard;
    this->price = price;
    this->duration_in_min = duration_in_min;
    this->no_of_tests = no_of_tests;
    course_code = i;
    i++;
}

// this function prints the details of the course opted by the user
void board::show_details()
{
    cout << endl
         << "Class: " << standard << endl;
    cout << "Price: " << price << endl;
    cout << "Total study hours: " << duration_in_min << endl;
    cout << "Total No. of Tests: " << no_of_tests << endl;
}

// this function takes mode of payement and purchases the course and uploads it to student profile
void board::purchase_course(string s)
{
    cout << endl
         << "Choose your mode of payment: " << endl;
    cout << "1. UPI/Net Banking\n2. Debit Card\n3. Credit Card\n"
         << endl;
    int x;
    bool c = true;
    while (c)
    {
        cin >> x;
        if (x <= 3 && x > 0)
        {
            cout << "You have purchased this course." << endl;
            s1.upload_course(s);
            break;
        }
        else if (x == 0)
        {
            break;
        }
        else
        {
            cout << endl
                 << "Invalid Input!!" << endl
                 << endl
                 << "Please try again" << endl
                 << "Or" << endl
                 << "Enter 0 to quit" << endl;
        }
    }
}
// this function returns the course code of board lecture
int board::get_code()
{
    return course_code;
}