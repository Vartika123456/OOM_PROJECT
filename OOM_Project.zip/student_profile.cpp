#include <bits/stdc++.h>
#include "student_profile.h" // Header file including all class declarations

using namespace OCMS;
using namespace std;

extern vector<string> purchased_courses;

void student_profile::register_student()
//this function take input of student name and mobile number and provide student id.
{
    cout << "Please enter Student's Name: ";
    cin.ignore();
    getline(cin, student_name);
    cout << "Please enter your Contact Number: ";
    cin >> mobile_no;
    while (mobile_no.size() != 10)
    {
        cout << endl
             << "Invalid Mobile Number!!.... Please enter again" << endl
             << endl;
        cout << "Please enter your Contact Number: ";
        cin >> mobile_no;
    }
    srand(time(0));
    student_id = 1 + rand() % 200;
    cout << endl
         << "You have Registered Successfully!!" << endl
         << endl;
    cout << "**The duration of every lecture you watch adds to your total study duration and shows up in your profile." << endl;
    cout << "**You will get one badge everytime after attempting two tests." << endl;
    cout << "**You can see your purchased course(s) in your profile." << endl;
}

void student_profile::show_student_profile()
// This functions prints student profile
{
    cout << endl
         << "Your Profile details are as follows: " << endl
         << endl;
    cout << "Student Name : " << student_name << endl
         << "Registered Mobile Number : " << mobile_no << endl
         << "Student ID : " << student_id << endl
         << "Total Study Duration : " << study_hours << " hrs " << min%60 << " mins " << endl
         << "Number of Badges : " << no_of_badges << endl
         << "Purchased Course : " << course_name << endl;
    cout << "Number of tests attempted : " << no_of_tests_attempted << endl
         << endl;
}

// This function increases study hours in student profile everytime the user watched a lecture
void student_profile::increase_watchtime(int i)
{
    min = min + i;
    study_hours = min / 60;
}

// this function provide 1 badge if student attempted 2 test
void student_profile::increase_badges()
{
    no_of_badges = no_of_tests_attempted / 2;
}

// this function updates the name of the course purchased in student profile
void student_profile::upload_course(string s)
{
    if (course_name == "NA")
    {
        course_name = s;
    }
    else
    {
        course_name += ", " + s;
    }
    purchased_courses.push_back(s);
}
// this function kept the count of test of student
void student_profile::increase_test_attempted()
{
    no_of_tests_attempted++;
}
