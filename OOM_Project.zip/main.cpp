#include <bits/stdc++.h>
#include <unistd.h>
#include "student_profile.h"
#include "lecture.h"
#include "free_lecture.h"
#include "board.h"
#include "competitive.h"
#include "test.h" // Header file including all class declarations

using OCMS::board;
using OCMS::competitive;
using OCMS::free_lecture;
using OCMS::lecture;
using OCMS::student_profile;
using OCMS::test;
using namespace std;

// Global declarations

student_profile s1;
vector<string> purchased_courses;

vector<int> codes;

int board::i = 0;

string pcm[] = {"Maths", "Physics", "Chemistry"};

string pcb[] = {"Biology", "Physics", "Chemistry"};

// list of free lectures and its other info
free_lecture f[] = {free_lecture(1, "Number System", 31, 126, 1254),
                    free_lecture(2, "Gravitation", 62, 515, 7392),
                    free_lecture(3, "Periodic Table", 43, 304, 4038),
                    free_lecture(4, "Control & Coordination", 75, 437, 6630),
                    free_lecture(5, "French Revolution", 84, 317, 5884),
                    free_lecture(6, "Reported Speech", 22, 296, 3762)};

//list of board-level courses and their info
board b[6] = {board("9th", "10000 INR", 100, 10),
              board("10th", "15000 INR", 200, 20),
              board("11th PCM", "20000 INR", 300, 30),
              board("11th PCB", "12000 INR", 300, 30),
              board("12th PCM", "20000 INR", 400, 40),
              board("12th PCB", "200 INR", 500, 50)};

//list of competitive level courses and their info
competitive comp[] = {
    competitive("9th & 10th", "50000 INR", 500, 50, "JEE(Mains + Adv)", 100, pcm),
    competitive("11th & 12th", "80000 INR", 600, 70, "JEE(Mains + Adv)", 100, pcm),
    competitive("9th & 10th", "60000 INR", 400, 50, "JEE(Mains)", 100, pcm),
    competitive("11th & 12th", "70000 INR", 600, 70, "JEE(Mains)", 100, pcm),
    competitive("9th & 10th", "60000 INR", 650, 70, "NEET-UG", 100, pcb),
    competitive("11th & 12th", "85000 INR", 600, 70, "NEET-UG", 100, pcb),
};

//list of board level tests and their info
test board_tests[][4] = {{test("Polynomials & Motion", 90, 100), test("Matter in our surrounding & Cells: The fundamental unit of life", 100, 150), test("Full Syllabus", 110, 200), test("Full Syllabus", 120, 250)},
                         {test("Trignometry & Electricity", 90, 100), test("Acid, Bases & Salts & Heredity & Evolution", 100, 150), test("Full Syllabus", 110, 200), test("Full Syllabus", 120, 250)},
                         {test("Limits & Derivatives & Rotational Body Dynamics", 90, 100), test("Structure of Atom & Isomerism", 100, 150), test("Full Syllabus", 110, 200), test("Full Syllabus", 120, 250)},
                         {test("Animal Kingdom & Rotational Body Dynamics", 90, 100), test("Structure of Atom & Isomerism", 100, 150), test("Full Syllabus", 110, 200), test("Full Syllabus", 120, 250)},
                         {test("Integration & Electromagnetism", 90, 100), test("Electrochemistry & Aromatic Compounds", 100, 150), test("Full Syllabus", 110, 200), test("Full Syllabus", 120, 250)},
                         {test("Molecular Basis of Inheritance & Electromagnetism", 90, 100), test("Electrochemistry & Aromatic Compounds", 100, 150), test("Full Syllabus", 110, 200), test("Full Syllabus", 120, 250)}};

//list of competitive-level tests and their info
test comp_tests[][4] = {{test("Polynomials", 90, 100), test("Cells: The fundamental of life", 100, 150), test("Matter in our surroundings", 110, 200), test("Motion", 120, 250)},
                        {test("Trignometry", 90, 100), test("Acid, Bases & Salts", 100, 150), test("Electricity", 110, 200), test("Heredity & Evolution", 120, 250)},
                        {test("Limits & Derivates", 90, 100), test("Rotational Body Dynamics", 100, 150), test("Structure of Atom", 110, 200), test("Isomerism", 120, 250)},
                        {test("Animal Kingdom", 90, 100), test("Rotational Body Dynamics", 100, 150), test("Structure of Atom", 110, 200), test("Isomerism", 120, 250)},
                        {test("Integration", 90, 100), test("Electromagnetism", 100, 150), test("Electrochemistry", 110, 200), test("Aromatic Compounds", 120, 250)},
                        {test("Molecular Basis of Inheritance", 90, 100), test("Electromagnetism", 100, 150), test("Electrochemistry", 110, 200), test("Aromatic Compounds", 120, 250)}};

//list of DPPs in different competitive level courses
string DPPs[][4] = {{"Polynomials", "Cells: The fundamental unit of life", "Matter in our surroundings", "Motion"},
                    {"Trignometry", "Acid, Bases & salts", "Electricity", "Heredity & Evolution"},
                    {"Limits & Derivatives", "Rotaional Body Dynamics", "Structure of Atom", "Isomerism"},
                    {"Limits & Derivatives", "Rotaional Body Dynamics", "Structure of Atom", "Isomerism"},
                    {"Integration", "Electromagnetism", "Electrochemistry", "Aromatic Compounds"},
                    {"Molecular Basis of Inheritance", "Electromagnetism", "Electrochemistry", "Aromatic Compounds"}};

//list of lectures in each board level course
lecture board_lecture[][4] = {{lecture(1, "Polynomials", 72), lecture(2, "Cells: The fundamental unit of life", 61), lecture(3, "Matter in our surroundings", 43), lecture(4, "Motion", 76)},
                              {lecture(1, "Trignometry", 116), lecture(2, "Acid, Bases & Salts", 105), lecture(3, "Electricity", 93), lecture(4, "Heredity & Evolution", 42)},
                              {lecture(1, "Limits & Derivates", 153), lecture(2, "Rotational Body Dynamics", 122), lecture(3, "Structure of Atom", 76), lecture(4, "Isomerism", 87)},
                              {lecture(1, "Animal Kingdom", 82), lecture(2, "Rotational Body Dynamics", 122), lecture(3, "Structure of Atom", 76), lecture(4, "Isomerism", 87)},
                              {lecture(1, "Integration", 123), lecture(2, "Electromagnetism", 112), lecture(3, "Electrochemistry", 77), lecture(4, "Aromatic Compounds", 69)},
                              {lecture(1, "Molecular Basis of Inheritance", 66), lecture(2, "Electromagnetism", 112), lecture(3, "Electrochemistry", 77), lecture(4, "Aromatic Compounds", 69)}};

//list of lectured in each competitive level course
lecture comp_lecture[][4] = {{lecture(1, "Polynomials", 72), lecture(2, "Cells: The fundamental unit of life", 61), lecture(3, "Matter in our surroundings", 43), lecture(4, "Motion", 76)},
                             {lecture(1, "Trignometry", 116), lecture(2, "Acid, Bases & Salts", 105), lecture(3, "Electricity", 93), lecture(4, "Heredity & Evolution", 42)},
                             {lecture(1, "Limits & Derivates", 153), lecture(2, "Rotational Body Dynamics", 122), lecture(3, "Structure of Atom", 76), lecture(4, "Isomerism", 87)},
                             {lecture(1, "Animal Kingdom", 82), lecture(2, "Rotational Body Dynamics", 122), lecture(3, "Structure of Atom", 76), lecture(4, "Isomerism", 87)},
                             {lecture(1, "Integration", 123), lecture(2, "Electromagnetism", 112), lecture(3, "Electrochemistry", 77), lecture(4, "Aromatic Compounds", 69)},
                             {lecture(1, "Molecular Basis of Inheritance", 66), lecture(2, "Electromagnetism", 112), lecture(3, "Electrochemistry", 77), lecture(4, "Aromatic Compounds", 69)}};

void show_lecture_list()
{
    cout << endl << "The list of free lecture is as follows: " << endl;
    for (int i = 0; i < 6; i++)
    {
        cout
            << endl
            << "Lecture No.: " << f[i].get_lecture_no() << endl;
        cout << "Lecture Name: " << f[i].get_name() << " " << endl
             << "Duration in minutes: " << f[i].get_duration() << endl
             << "Views: " << f[i].get_views() << endl
             << "Likes: " << f[i].get_likes() << endl;
        if (f[i].watched())
        {
            cout << "Watched: Yes" << endl;
        }
        else
        {
            cout << "Watched: No" << endl;
        }
    }
}

// this function takes lecture number as input and provide various options to watch, like etc.
void watch_lectures()
{
    int no;
    string button2;
    bool c = true;
    cout << endl
         << "Please enter the Lecture No. you want to watch: " << endl;
    cout << "Or" << endl
         << "Enter 0 to Quit" << endl
         << endl;
    while (c)
    {
        cin >> no;
        if (no > 0 && no <= 6)
        {
            int i = no - 1;
            c = false;
            cout << endl
                 << "You are watching \"" << f[i].get_name() << "\" lecture....";
            sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\nYou have watched the lecture." << endl
                 << endl;
            f[i].increase_views();
            f[i].change_watched();
            s1.increase_watchtime(f[i].get_duration());
            bool b = true;
            while (b)
            {
                cout << "Enter W to watch another lecture" << endl;
                cout << "Enter L to like lecture and quit" << endl;
                cout << "Enter D to download lecture and quit" << endl;
                cout << "Enter Q to quit" << endl
                     << endl;

                cin >> button2;

                if (button2 == "w" || button2 == "W")
                {
                    watch_lectures();
                    b = false;
                }
                else if (button2 == "L" || button2 == "l")
                {
                    f[i].like_lecture();
                    b = false;
                }
                else if (button2 == "D" || button2 == "d")
                {
                    f[i].download_lecture();
                    b = false;
                }

                else if (button2 == "Q" || button2 == "q")
                {
                    b = false;
                }
                else
                {
                    cout << endl
                         << "Invalid Input!!.... Please try again." << endl
                         << endl;
                }
            }
            break;
        }
        if (no == 0)
            break;

        if (c)
            cout << endl
                 << "Couldn't find your lecture!!.... Please try again." << endl
                 << endl;
    }
}

int main()
{
    cout << "WELCOME TO OUR ONLINE COURSE MANAGEMENT SYSTEM" << endl << endl;
    bool registration = false;
    while (0 == 0)
    {
        //showing different options to start with
        cout << ". . . . . . . . . . . . . . . . . . . ." << endl;
        cout << "Enter R to register" << endl;
        cout << "Enter F to view Free Lectures" << endl;
        cout << "Enter P to view Paid Lectures" << endl;
        cout << "Enter N to navigate through your purchased courses" << endl;
        cout << "Enter V to view profile" << endl;
        cout << "Enter E to exit" << endl;
        cout << ". . . . . . . . . . . . . . . . . . . ." << endl;
        string c;
        cin >> c;

        if (c == "R" || c == "r")
        {
            // Registering student if the user presses R
            if (registration == false)
            {
                s1.register_student();
                s1.show_student_profile();
                registration = true;
            }
            else
            {
                // Message if the student has already registered as tries to register again
                cout << endl
                     << "You have already registered!!.... Please go ahead!" << endl
                     << endl;
            }
        }

        else if (c == "F" || c == "f")
        {
            // showing the lecture list and providing various functions
            show_lecture_list();
            string button;
            cout << endl
                 << "Enter W to watch lecture" << endl;
            cout << "Enter Q to quit" << endl
                 << endl;
            cin >> button;

            while (button != "W" && button != "w" && button != "q" && button != "Q")
            {
                cout << endl
                     << "Invalid Input!!.... Please try again." << endl;
                cout << endl
                     << "Enter W to watch lecture" << endl;
                cout << "Enter Q to quit" << endl
                     << endl;
                cin >> button;
            }
            if (button == "W" || button == "w")
            {
                watch_lectures();
            }
        }

        else if (c == "P" || c == "p")
        {
            //showing list of paid courses if the user presses P
            bool n = true;
            while (n)
            {
                // asking if the user need board level courses or competitive level courses
                cout << endl
                     << "Enter B to select Board-level courses" << endl;
                cout << "Enter C to select Competitive level courses" << endl;
                cout << "Enter Q to quit" << endl
                     << endl;
                string a;
                int x;
                cin >> a;
                if (a == "B" || a == "b")
                {
                    //showing board level courses
                    n = false;
                    bool w = true;
                    while (w)
                    {
                        cout << endl
                             << "Please select your class (9th-12th):" << endl;
                        // taking class as input
                        cin >> x;
                        if (x == 9)
                        {
                            w = false;
                            b[0].show_details();
                        }
                        else if (x == 10)
                        {
                            w = false;
                            b[1].show_details();
                        }
                        else if (x == 11 || x == 12)
                        {
                            w = false;
                            string stream;
                            cout << "Please enter your majors (PCB or PCM?):" << endl;
                            // taking the majors (pcm/pcb) as input
                            cin >> stream;
                            if (x == 11 && (stream == "PCM" || stream == "pcm"))
                            {
                                b[2].show_details();
                            }
                            else if (x == 11 && (stream == "PCB" || stream == "pcb"))
                            {
                                b[3].show_details();
                            }
                            else if (x == 12 && (stream == "PCM" || stream == "pcm"))
                            {
                                b[4].show_details();
                            }
                            else if (x == 12 && (stream == "PCB" || stream == "pcb"))
                            {
                                b[5].show_details();
                            }
                        }
                        else
                        {
                            cout << endl
                                 << "Invalid Input!!.... Please try again." << endl;
                        }
                    }
                    string y;
                    cout << "Do you want to purchase the course (y/n)?" << endl;
                    cin >> y;

                    while (y != "y" && y != "Y" && y != "n" && y != "N")
                    {
                        cout << endl
                             << "Invalid Input!!.... Please try again." << endl
                             << endl
                             << "Do you want to purchase the course (y/n)?" << endl;
                        cin >> y;
                    }
                    if (y == "Y" || y == "y")
                    {
                        if (registration == false)
                        {
                            // error if the student is not registered
                            cout << endl
                                 << "Sorry!! You are not registered student." << endl;
                            cout << "To get the benefits of paid course please register first." << endl
                                 << endl;
                        }
                        else
                        {
                            //adding the course to student profile
                            string st;
                            st = "Class " + to_string(x) + "th Board-Level";
                            b[x - 9].purchase_course(st);
                            codes.push_back(b[x - 9].get_code());
                            s1.show_student_profile();
                        }
                    }
                }

                else if (a == "C" || a == "c")
                {
                    n = false;
                    int a;
                    cout << endl
                         << "The list of Competitive-level courses is as follows:" << endl;
                    for (int i = 0; i < 6; i++)
                    {
                        cout << i + 1 << ". " << comp[i].get_standard() << " " << comp[i].get_exam_type() << endl;
                    }
                    cout << endl
                         << "Please enter the course no. you want to purchase:" << endl;
                    cin >> a;
                    while (a > 6 || a < 1)
                    {
                        cout << endl
                             << "Invalid Input!!.... Please try again." << endl;
                        cout << endl
                             << "Please enter the course no. you want to purchase (1-6):" << endl;
                        cin >> a;
                    }
                    comp[a - 1].show_details();

                    string y;
                    cout << "Do you want to purchase the course (y/n)?" << endl;
                    cin >> y;

                    while (y != "y" && y != "Y" && y != "n" && y != "n")
                    {
                        cout << endl
                             << "Invalid Input!!.... Please try again." << endl
                             << endl
                             << "Do you want to purchase the course (y/n)?" << endl;
                        cin >> y;
                    }
                    if (y == "y" || y == "Y")
                    {
                        if (registration == false)
                        {
                            cout << endl
                                 << "Sorry!! You are not registered student." << endl;
                            cout << "To get the benefits of paid course please register first." << endl
                                 << endl;
                        }
                        else
                        {
                            string str;
                            str = "Class " + comp[a - 1].get_standard() + " " + comp[a - 1].get_exam_type();
                            b[a - 1].purchase_course(str);
                            s1.show_student_profile();
                            codes.push_back(comp[a - 1].get_code());
                        }
                    }
                }
                else if (a == "Q" || a == "q")
                {
                    n = false;
                }
                else
                {
                    cout << endl
                         << "Invalid Input!!.... Please try again." << endl;
                }
            }
        }
        else if (c == "N" || c == "n")
        {
            bool m = true;
            if (purchased_courses.size() == 0)
            {
                //error if the student has not purchased any course
                cout << endl
                     << "It looks like you haven't purchased any course yet." << endl
                     << endl;
                m = false;
            }
            else
            {
                cout << endl
                     << "You have purchased the following course(s): " << endl;
                for (int i = 0; i < purchased_courses.size(); i++)
                {
                    cout << i + 1 << ". " << purchased_courses[i] << endl;
                }
            }
            while (m)
            {
                cout << endl
                     << "Enter S to select one of the courses" << endl
                     << "Or" << endl;
                cout << "Enter Q to quit" << endl;

                string button3;
                cin >> button3;
                int serial;
                if (button3 == "S" || button3 == "s")
                {
                    // selecting a specific sourse
                    m = false;
                    cout << endl
                         << "Enter the course no. you want to view: " << endl;
                    cin >> serial;
                    while (serial < 1 || serial > purchased_courses.size())
                    {
                        cout << endl
                             << "Invalid Input!!.... Please try again." << endl;
                        cout << endl
                             << "Enter the course no. you want to view: " << endl;
                        cin >> serial;
                    }
                    cout << endl
                         << "You have selected the \"" << purchased_courses[serial - 1] << "\" course" << endl;
                    bool p = true;
                    while (p)
                    {
                        // showing different options after selecting a specific course
                        cout << endl
                             << "Enter W to watch a lecture" << endl;
                        cout << "Enter T to attempt a test" << endl;
                        cout << "Enter A to go to doubt section" << endl;
                        for (int i = 0; i < 6; i++)
                        {
                            if (codes[serial - 1] == comp[i].get_code())
                            {
                                // extra options if it is of competitive level
                                cout << "Enter D to download DPPs" << endl;
                                cout << "Enter F to download formula book" << endl;
                            }
                        }
                        cout << "Enter Q to quit" << endl;

                        string button4;
                        cin >> button4;
                        if (button4 == "T" || button4 == "t")
                        {
                            // showing lecture lists if user selects test options

                            int testno;
                            cout << endl
                                 << "This course contains following tests: " << endl
                                 << endl;
                            for (int i = 0; i < 6; i++)
                            {
                                if (codes[serial - 1] == b[i].get_code())
                                {
                                    for (int j = 0; j < 4; j++)
                                    {
                                        cout << "Test number: " << j + 1 << endl;
                                        board_tests[i][j].print_details();
                                    }
                                }
                            }

                            for (int i = 0; i < 6; i++)
                            {
                                if (codes[serial - 1] == comp[i].get_code())
                                {
                                    for (int j = 0; j < 4; j++)
                                    {
                                        cout << "Test number: " << j + 1 << endl;
                                        comp_tests[i][j].print_details();
                                    }
                                }
                            }
                            cout
                                << "Select one of the tests from above list" << endl;

                            cin >> testno;
                            while (testno > 4 || testno < 1)
                            {
                                cout << endl
                                     << "Invalid Input!!.... Please try again." << endl;
                                cout << endl
                                     << "Select one of the tests from above list" << endl;
                                cin >> testno;
                            }
                            // if the student have selected a test
                            cout << endl
                                 << "You are attempting this test....";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\nYou have attempted this test."
                                 << endl;
                            s1.increase_test_attempted();
                            s1.increase_badges();
                            cout << "Your scorecard will be sent to you soon via SMS" << endl;
                        }
                        else if (button4 == "D" || button4 == "d")
                        {
                            // showing list of DPPs if the user selects download dpp option
                            if (codes[serial - 1] >= 7)
                            {

                                cout << "This course contains following DPPs: " << endl
                                     << endl;
                                for (int i = 0; i < 6; i++)
                                {
                                    if (codes[serial - 1] == comp[i].get_code())
                                    {
                                        for (int j = 0; j < 4; j++)
                                        {
                                            cout << j + 1 << ". " << DPPs[i][j] << endl;
                                        }
                                    }
                                }
                                cout << endl
                                     << "Select one of the DPPs from above list" << endl;

                                int no;
                                cin >> no;
                                while (no > 4 || no < 1)
                                {
                                    cout << endl
                                         << "Invalid Input!!.... Please try again." << endl;
                                    cout << endl
                                         << "Select one of the DPPs from above list" << endl;
                                    cin >> no;
                                }
                                cout << endl
                                     << "Your DPP is being downloaded....";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\nYour DPP has been downloaded." << endl;
                            }
                            else
                            {
                                cout << "Invalid Input!!.... Please try again." << endl;
                            }
                        }
                        else if (button4 == "W" || button4 == "w")
                        {
                            // showing lecture list if student selects watch option
                            int lecno;
                            int classno;
                            bool course = false;
                            cout << endl
                                 << "This course contains following lectures: " << endl
                                 << endl;
                            for (int i = 0; i < 6; i++)
                            {
                                if (codes[serial - 1] == b[i].get_code())
                                {
                                    classno = i;
                                    course = true;
                                    for (int j = 0; j < 4; j++)
                                    {
                                        board_lecture[i][j].details();
                                    }
                                }
                            }

                            for (int i = 0; i < 6; i++)
                            {
                                if (codes[serial - 1] == comp[i].get_code())
                                {
                                    classno = i;
                                    for (int j = 0; j < 4; j++)
                                    {

                                        comp_lecture[i][j].details();
                                    }
                                }
                            }
                            cout << "Please select one of the lectures from above list" << endl;
                            cin >> lecno;
                            while (lecno > 4 || lecno < 1)
                            {
                                cout << endl
                                     << "Invalid Input!!.... Please try again." << endl;
                                cout << endl
                                     << "Please select one of the lectures above" << endl;
                                cin >> lecno;
                            }
                            cout << endl
                                 << "You are watching this lecture....";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\n.";
                            sleep(2);
                            cout << "\nYou have watched this lecture." << endl;
                            if (course == true)
                            {
                                board_lecture[classno][lecno - 1].change_watched();
                                s1.increase_watchtime(board_lecture[classno][lecno - 1].get_duration());
                            }
                            else
                            {
                                comp_lecture[classno][lecno - 1].change_watched();
                                s1.increase_watchtime(comp_lecture[classno][lecno - 1].get_duration());
                            }
                        }

                        else if (button4 == "a" || button4 == "A")
                        {
                            // taking doubt as input if user selects doubt section
                            cout << endl
                                 << "Please enter your doubt..." << endl;
                            string doubt;
                            cin.ignore();
                            getline(cin, doubt);
                            cout << endl
                                 << "Your doubt has been posted" << endl;
                            cout << "Please wait for the reply!" << endl;
                        }
                        else if (button4 == "f" || button4 == "F")
                        {
                            // showing formula book list if user selects formula book option
                            if (codes[serial - 1] >= 7)
                            {
                                int button5;
                                cout << endl
                                     << "This course contains following formula books: " << endl;
                                if (codes[serial - 1] >= 7 && codes[serial - 1] <= 10)
                                {
                                    cout << "1. Mathematics" << endl
                                         << "2. Physics" << endl
                                         << "3. Chemistry" << endl
                                         << endl;
                                }
                                else
                                {
                                    cout << "1. Biology" << endl
                                         << "2. Physics" << endl
                                         << "3. Chemistry" << endl
                                         << endl;
                                }
                                cout << "Please select one of the formula books from above list" << endl;
                                cin >> button5;
                                while (button5 > 3 || button5 < 1)
                                {
                                    cout << endl
                                         << "Invalid Input!!.... Please try again." << endl;
                                    cout << endl
                                         << "Please select one of the formula books above" << endl;
                                    cin >> button5;
                                }
                                cout << endl
                                     << "Your formula book is being downloaded...";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\n.";
                                sleep(2);
                                cout << "\nYour formula book has been downloaded!" << endl;
                            }
                            else
                            {
                                cout << endl
                                     << "Invalid Input!!.... Please try again." << endl;
                            }
                        }
                        else if (button4 == "q" || button4 == "Q")
                        {
                            p = false;
                        }
                        else
                        {
                            p = true;
                            cout << endl
                                 << "Invalid Input!!.... Please try again." << endl;
                        }
                    }
                }
                else if (button3 == "Q" || button3 == "q")
                {
                    m = false;
                }
                else
                {
                    cout << endl
                         << "Invalid Input!!.... Please try again." << endl;
                }
            }
        }
        else if (c == "V" || c == "v")
        {
            // showing student profile
            if (registration)
            {
                s1.show_student_profile();
            }
            else
            {
                cout << endl
                     << "Sorry!! You are not a registered Student." << endl;
                cout << "Please Register first." << endl
                     << endl;
            }
        }
        else if (c == "e" || c == "E")
        {
            // exiting if user selects exit option
            cout << endl
                 << "Thanks for coming!!" << endl;
            break;
        }
        else
        {
            cout << endl
                 << "Invalid Input!!.... Please try again." << endl
                 << endl;
        }
    }
}