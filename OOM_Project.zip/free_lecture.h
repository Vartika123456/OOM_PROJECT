#ifndef __free_lecture
#define __free_lecture

#include <string.h>
#include "lecture.h"

using std::string;

namespace OCMS
{	
	//A derived class of lecture used for free lectures
	class free_lecture : public lecture{
		
		private:
		int views;
		int likes;

		public:
		free_lecture(int, string, int, int, int);
		int get_likes();
		int get_views();
		void increase_views();
		void like_lecture();
		void download_lecture();
	};
}
#endif