#include <bits/stdc++.h>
#include "lecture.h" // Header file including all class declarations

using namespace OCMS;
using namespace std;

// constructor for initialising the value of lecture_no,lecture_name,duration
lecture::lecture(int lecture_no, string lecture_name, int duration)
{
    this->lecture_no = lecture_no;
    this->lecture_name = lecture_name;
    this->duration = duration;
}
// provide the details of the lecture that student had choosen.
void lecture::details()
{
    cout << "Lecture number: " << lecture_no << endl;
    cout << "Lecture name: " << lecture_name << endl;
    cout << "Duration: " << duration << endl;
    cout << "Watched: ";
    if (checkbox == true)
    {
        cout << "Yes" << endl
             << endl;
    }
    else
    {
        cout << "No" << endl
             << endl;
    }
}
int lecture::get_lecture_no()
{
    return lecture_no;
}
string lecture::get_name()
{
    return lecture_name;
}
int lecture::get_duration()
{
    return duration;
}
bool lecture::watched()
{
    return checkbox;
}
void lecture::change_watched()
{
    checkbox = true;
}