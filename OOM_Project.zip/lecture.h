#ifndef __lecture
#define __lecture

#include <string>
using std::string;
namespace OCMS
{	
	//Class used for paid lectures provided in each course 
	class lecture
	{
	protected:
		string lecture_name;
		bool checkbox = false;
		int duration;
		int i;
		int lecture_no;

	public:
		lecture(int, string, int);
		int get_lecture_no();
		string get_name();
		int get_duration();
		bool watched();
		void change_watched();
		void details();
	};
}
#endif