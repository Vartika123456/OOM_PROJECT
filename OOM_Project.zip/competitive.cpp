#include <bits/stdc++.h>
#include "board.h"
#include "competitive.h" // Header file including all class declarations

using OCMS::board;
using OCMS::competitive;
using namespace std;

competitive::competitive(string standard, string price, int duration_in_min, int no_of_tests, string exam_type, int no_of_dpps, string books[])
    : board(standard, price, duration_in_min, no_of_tests)
{
    this->exam_type = exam_type;
    this->no_of_dpps = no_of_dpps;
    formula_book[0] = books[0];
    formula_book[1] = books[1];
    formula_book[2] = books[2];
}

// this function is an updated function for showing the details of competitive-level courses
void competitive::show_details()
{
    board::show_details();
    cout << "Competitive course type: " << exam_type << endl;
    cout << "Number of DPPs: " << no_of_dpps << endl;
    cout << "Formula Books provided: " << formula_book[0] << ", " << formula_book[1] << ", " << formula_book[2] << endl
         << endl;
}

string competitive::get_standard()
{
    return standard;
}

string competitive::get_exam_type()
{
    return exam_type;
}