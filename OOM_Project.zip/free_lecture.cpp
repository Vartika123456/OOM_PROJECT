#include <bits/stdc++.h>
#include <unistd.h>
#include "lecture.h"
#include "free_lecture.h" // Header file including all class declarations

using OCMS::lecture;
using OCMS::free_lecture;
using namespace std;

int free_lecture::get_likes()
{
    return likes;
}
int free_lecture::get_views(){
    return views;
}

// this function increases the number of likes of a free lecture when the user presses like button
void free_lecture::like_lecture()
{
    likes++;
    cout << endl
         << "You have liked \"" << lecture_name << "\" lecture." << endl
         << endl;
}

// this function downloads the lecture when the user presses the download button
void free_lecture::download_lecture()
{
    cout << endl
         << "\"" << lecture_name << "\" lecture is downloading....";
         sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\n.";
            sleep(2);
            cout << "\n.";
            sleep(2);
         cout << "\nYour lecture has been downloaded." << endl
         << endl;
}

// this function update the views of the lecture that is watch by the student.// this function increase the number of views of free lecture by one if the user watches that lecture
void free_lecture::increase_views()
{
    views++;
}

// contructor function for free lectures
free_lecture::free_lecture(int lecture_no, string lecture_name, int duration, int likes, int views)
    : lecture(lecture_no, lecture_name, duration)
{
    this->likes = likes;
    this->views = views;
}