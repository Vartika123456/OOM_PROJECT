#ifndef __student_profile
#define __student_profile

#include <string>
using std::string;
namespace OCMS
{	
	// Class for student profile after registration
	class student_profile
	{
	private:
		string student_name;
		string mobile_no;
		int student_id = 0;
		int study_hours = 0;
		int no_of_badges = 0;
		string course_name = "NA";
		int no_of_tests_attempted = 0;
		int min = 0;

	public:
		void show_student_profile();
		void register_student();
		void upload_course(string s);
		void increase_watchtime(int t);
		void increase_test_attempted();
		void increase_badges();
	};
}
#endif