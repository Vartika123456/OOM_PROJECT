#ifndef __test
#define __test

#include <string>
#include "lecture.h"

using std::string;
namespace OCMS
{	
    // Class for tests given in paid courses
	class test
	{
	private:
		string syllabus;
		int duration;
		int max_marks;
		bool attempted = false;

	public:
		test(string, int, int);
		void print_details();
	};
}
#endif