#include <bits/stdc++.h>
#include "test.h" // Header file including all class declarations

using OCMS::test;
using namespace std;

// contructor function for tests
test::test(string syllabus, int duration, int max_marks)
{
    this->syllabus = syllabus;
    this->duration = duration;
    this->max_marks = max_marks;
}

// this function prints the details of the tests of a particular course
void test::print_details()
{
    cout << "Syllabus of the exam is: " << syllabus << endl;
    cout << "Duration of the exam is: " << duration << " minutes" << endl;
    cout << "Maximum marks: " << max_marks << endl;
    cout << "Attempted: ";
    if (attempted == true)
    {
        cout << "Yes" << endl
             << endl;
    }
    else
    {
        cout << "No" << endl
             << endl;
    }
}